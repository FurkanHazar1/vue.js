# vue-cli

> Vue Projesiin Projenin olduğu yere gelerek

# bağımlılıkları yüklemek için
npm install

# uygulamayı çalıştırmak için
npm run dev

# projeyi production ortamına derlemek için
npm run build