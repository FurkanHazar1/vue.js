<template>
  <div class="wcol-md-6">
    <h3>Child Component 1</h3>
    <p>Ben User.vue isimli Parent Component'in içerisindeki bir Child componentim</p>
    <p>kullanıcı adı: {{name}}</p>
    <p>kullanıcı yaşı: {{age}}</p>
    <button @click="sendToParent()">parent'a yolla</button>
  </div>
</template>
<script>
import {eventBus} from '../main'
  export default{
    props:["name","age"],
        methods:{
        sendToParent(){
          return this.$emit("data","araba");
        }
      },
    created(){
      eventBus.$on("changeAge",(age)=>{
        this.age="30"
      })

    }

  }

</script>
<style scoped>
  div {
    background-color: lightcoral;
    padding: 20px;
    border: 1px solid #666;
    display: inline-block;
  }
</style>
