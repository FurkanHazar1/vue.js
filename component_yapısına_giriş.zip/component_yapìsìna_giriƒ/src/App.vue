<template>
  <div class="container">
    <heder></heder>
    <div class="row">
      <sunucu></sunucu>
      <yan></yan>
    </div>
    <foter></foter>
  </div>
</template>

<script>
import footer from "./common/basliklar/footer";
import header from "./common/basliklar/header.vue";
import yan from "./common/icerikler/yan.vue";
import sunucu from "./common/icerikler/sunucular";
export default{
  
  components: {
    'foter' :footer,
    "heder" :header,
    "yan" :yan,
    "sunucu" :sunucu
  }
}
</script>

<style>

</style>
