<template>
 <li class="list-group-item">
            Sunucu Durumu :{{serverData.status}} <br>
            Sunucu İd : {{serverData.id}}
          </li>
</template>
<script>

export default{
    props: ["serverData"]
}
</script>