<template>
 
     <div class="col-xs-12 col-sm-6">
        <p>Sunucu Bilgisi güncel !!</p>
      </div>
 
</template>
<script>

</script>