<template>
<div class="col-xs-12 col-sm-6">
        <ul class="list-group">
       <List v-for="server in servers" :serverData="server"></List>
        </ul>
</div>
 
</template>
<script>

import List from './list.vue'

export default{
    components: { List },
         data:function(){
            return{
                servers: [
                    {id:"1" ,status:"normal"},
                    {id:"2" ,status:"tehlikeli"},
                    {id:"3" ,status:"bilinmiyor"},
                    {id:"4" ,status:"bekleniyor"},
                ]
            }
        },

}

</script>
 
 