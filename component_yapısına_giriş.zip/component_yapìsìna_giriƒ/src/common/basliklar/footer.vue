<template>
<div>
  <hr>
    <div class="row">
      <div class="col-xs-12">
        <footer>
          <p>Tüm Hakları Saklı</p>
        </footer>
      </div>
    </div>
</div>
</template>

<script>

</script>