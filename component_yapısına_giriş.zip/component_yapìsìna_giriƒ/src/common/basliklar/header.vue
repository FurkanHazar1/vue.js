<template>
    <div>
        <div class="row">
        <div class="col-xs-12">
            <header>
            <h1>Sunucu Durumu </h1>
            </header>
        </div>
        </div>
        <hr>
    </div>
</template>
<script></script>